export function someGetter(/* state */) {}
