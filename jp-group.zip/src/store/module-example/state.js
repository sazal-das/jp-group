export default function () {
  return {
    //
  };
}
